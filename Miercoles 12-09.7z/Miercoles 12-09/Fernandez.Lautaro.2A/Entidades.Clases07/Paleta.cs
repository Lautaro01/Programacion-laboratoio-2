using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Clases07
{
    public class Paleta
    {

    #region Atributos
    private Tempera[] _colores;
    private int _CantidadMaximaElementos;
    #endregion

    #region Constructor
    private Paleta() : this(5)
    {
      
    }

    private Paleta(int cantidad)
    {
      this._CantidadMaximaElementos = cantidad;
      this._colores = new Tempera[this._CantidadMaximaElementos];
    }
    #endregion

    #region Metodos
    private string Mostrar()
    {
      string retornar = "";

      retornar += "Cantidad maxima de elementos: " + this._CantidadMaximaElementos + "\n";

      if(!(object.Equals(this._colores,null)))
      {
        foreach(Tempera info in this._colores)
        {
         retornar += (string)info;
        }
      }
      

      return retornar;
    }


    private int ObtenerIndice()
    {
      int retorno = -1;

      for(int i=0; i<this._CantidadMaximaElementos;i++)
      {
        if(this._colores[i] == null)
        {
          retorno = i;
          break;
        }
      }
      return retorno;
    }

    private int ObtenerIndice(Tempera tempera)
    {
      int retorno = -1;

      for (int i = 0; i < this._CantidadMaximaElementos; i++)
      {
        if (this._colores[i] != null)
        {
          if(this._colores[i] == tempera)
              retorno = i;
              break;
        }
      }
      return retorno;

    }

    #endregion

    #region Sobrecarga

    public static explicit operator string(Paleta paleta)
    {
      return paleta.Mostrar();
    }


    public static implicit operator Paleta(int cantidad)
    {
      return new Paleta(cantidad);
    }


    public static bool operator ==(Paleta paleta, Tempera tempera)
    {
      bool retorno = false;

      for(int i=0; i<paleta._CantidadMaximaElementos; i++)
      {
        if(paleta._colores[i] != null)
        {
          if(paleta._colores[i] == tempera)
          {
            retorno = true;
            break;
          }
        }
      }
      return retorno;         
    }


    public static bool operator !=(Paleta paleta, Tempera tempera)
    {
      return !(paleta == tempera);
    }

    public static Paleta operator +(Paleta paleta, Tempera tempera)
    {
      if(paleta == tempera)
      {
        int indice = paleta.ObtenerIndice(tempera);
        paleta._colores[indice] += tempera;
      }
      else
      {
        int indice = paleta.ObtenerIndice();
        if (indice > -1)
        {
          paleta._colores[indice] = tempera;
        }
        else
        {
          paleta._colores[0] = tempera;
        }
          

      }
      return paleta;
    }


    public static Paleta operator -(Paleta paleta,Tempera tempera)
    {
      if(paleta == tempera)
      {
        int indice = paleta.ObtenerIndice(tempera);
        
        paleta._colores[indice] -= tempera;

        if ((sbyte)paleta._colores[indice] <= 0)
        {
          paleta._colores[indice] = null;
        }
      }
      return paleta;
    }

    #endregion
  }



}
