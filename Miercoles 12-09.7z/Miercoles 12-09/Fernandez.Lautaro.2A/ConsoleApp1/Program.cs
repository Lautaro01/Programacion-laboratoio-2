using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clases07;

namespace Entidades.Clases07
{
  class Program
  {
    
    static void Main(string[] args)
    {
       Tempera temperaAzul = new Tempera(10, ConsoleColor.Blue, "marca1");
      Console.Write("Muestro la tempera\n\n");
      Console.Write(temperaAzul);

      Paleta paleta = 5;

      paleta += temperaAzul;

      Console.Write("Muestro la paleta\n\n");
      Console.Write((string)paleta);


      Console.ReadLine();
    }
  }
}
