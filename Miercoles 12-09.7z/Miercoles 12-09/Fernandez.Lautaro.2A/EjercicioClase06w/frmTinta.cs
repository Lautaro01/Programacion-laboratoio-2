using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase06w
{
  public partial class frmTinta : Form
  {
    public frmTinta()
    {
      InitializeComponent();
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
        {
        this.cboColor.Items.Add(color);
        }
      this.cboColor.SelectedItem = ConsoleColor.Blue;

      this.cboColor.DropDownStyle = ComboBoxStyle.DropDownList;

      foreach(Etipotinta tinta in Enum.GetValues(typeof(Etipotinta)))
      {
        this.cboTinta.Items.Add(tinta);
      }

      this.cboTinta.DropDownStyle = ComboBoxStyle.DropDownList;

      this.cboTinta.SelectedItem = Etipotinta.conBrillito;


    }

      

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
    {
      
             
       
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
  }
}
