using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase06
{
  class Pluma
  {

    #region Atributos
    private string _marca;
    private int _cantidad;
    private Tinta _tinta;
    #endregion

    #region Metodos

    private string Mostrar()
    {
      string retornar = " ";

      retornar += this._marca;
      retornar += "-";
      retornar += this._cantidad;
      retornar += "-";
      retornar += Tinta.Mostrar(this._tinta);

      return retornar;
    }

    #endregion

    #region Constructores
    public Pluma()
    {
      this._marca = "Sin marca";
      this._cantidad = 0;
      this._tinta = null;

    }

    public Pluma( string marca) :this()
    {
      this._marca = marca;
    
    }

    public Pluma( int cantidad, string marca) :this(marca)
    {

      this._cantidad = cantidad;
      this._marca = marca;
    }

    public Pluma(int cantidad, string marca, Tinta tinta) : this(cantidad,marca)
    {
      this._cantidad = cantidad;
      this._marca = marca;
      this._tinta = tinta;
    }

    #endregion

    #region Sobrecarga

    public static implicit operator string(Pluma plumita)
    {
      return plumita.Mostrar();
    }

    public static bool operator ==(Pluma plumita, Tinta tinta)
    {

      return plumita._tinta == tinta;
    }

    public static bool operator !=(Pluma plumita, Tinta tinta)
    {
      return !(plumita == tinta);
    }

    public static Pluma operator +(Pluma plumita, Tinta tinta)
    {
      Pluma retorno = plumita;

      if (plumita == tinta)
      {
        if (plumita._cantidad < 90)
        {

          plumita._cantidad += 10;
          retorno = plumita;
        }
        else
        {
          plumita._cantidad += 100 - plumita._cantidad;
        }
        
      }
      return retorno;
    }

    public static Pluma operator -(Pluma plumita, Tinta tinta)
    {
      Pluma retorno = plumita;

      if (plumita == tinta)
      {
        if(plumita._cantidad >= 10)
        {
          plumita._cantidad -= 10;
        }
        else
        {
          plumita._cantidad = 0;
        }       
      }
      return retorno;
    }



    #endregion


  }
}
