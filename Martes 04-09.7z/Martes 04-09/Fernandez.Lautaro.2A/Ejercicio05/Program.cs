﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class Ejercicio_04
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 04";

            int contadorDeNumerosPerfectos = 0;
            int numero = 1;
            int divisor = 1;
            int acumuladorDivisores = 0;

            while (contadorDeNumerosPerfectos < 4)
            {
                if (numero % divisor == 0)
                {
                    acumuladorDivisores += divisor;
                }
                              
                if(divisor == numero)
                {
                    if(numero == (acumuladorDivisores - numero))
                    {
                    Console.Write("Numero perfecto N°{1}: {0}\n", numero,contadorDeNumerosPerfectos);
                    contadorDeNumerosPerfectos++;
                    }

                    numero++;
                    divisor = 1;
                    acumuladorDivisores = 0;
                }
                else
                {
                    divisor++;
                }                            
            }

            Console.Read();
        }
    }
}
