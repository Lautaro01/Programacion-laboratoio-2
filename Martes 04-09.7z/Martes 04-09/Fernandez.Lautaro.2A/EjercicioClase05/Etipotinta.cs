public enum Etipotinta
{
  comun,
  china,
  conBrillito
}
