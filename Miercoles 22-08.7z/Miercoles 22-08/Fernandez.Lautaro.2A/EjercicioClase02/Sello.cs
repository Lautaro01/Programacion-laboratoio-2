﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Sello
    {
        public static string mensaje;

        public static string imprimir()
        {

            return Sello.mensaje;
        }

        public static void borrar()
        {
            mensaje = "";
        }

        public static ConsoleColor color;

        public static void ImprimirEnColor()
        {
            Console.BackgroundColor = Sello.color;
            Console.WriteLine(Sello.imprimir());

        }


    }
}
