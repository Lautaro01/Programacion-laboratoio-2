﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Sello
    {

        public static string mensaje;
        public static ConsoleColor color;


        public static void pedirSello()
        {
            Console.Write("Ingrese el sello: ");
            mensaje = Console.ReadLine();
            int cantidad = mensaje.Length;

            while(cantidad == 0)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("\nERROR! ingrese una palabra.");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.Write("\n\nIngrese el sello: ");
                mensaje = Console.ReadLine();
                cantidad = mensaje.Length;
            }
        }

        public static string imprimir()
        { 
            return Sello.mensaje;
        }

        public static void borrar()
        {
            mensaje = "";
        }

        public static void ImprimirEnColor()
        {
            Console.BackgroundColor = Sello.color;
            Console.WriteLine(Sello.imprimir());
        }

        public static void ImprimirSello()
        {
            string asteriscos="**";
            int cantidadAsteriscos;
            cantidadAsteriscos = Sello.mensaje.Length;
         
            for(int i = 0; i < cantidadAsteriscos; i++)
            {
                asteriscos += "*";
            }

            Console.BackgroundColor = Sello.color;
            Console.Write("{0}\n*{1}*\n{0}",asteriscos,Sello.mensaje);

        }
    }
}
