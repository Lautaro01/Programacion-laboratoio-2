using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Tinta unaTinta = new Tinta();
      Tinta otraTinta = new Tinta();

      if(unaTinta == otraTinta)
      {
        Console.Write("Las tintas son iguales");
        Tinta.Mostrar(unaTinta);
      }
      else


      Console.ReadLine();
    }
  }
}
