﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio01
{
    class Ejercicio_01
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 01";

            int numero;
            int maximo=0;
            int minimo=0;
            int acumulador = 0;
            float promedio = 0;
            int i;
            bool flat = true;

            for(i = 0; i < 5; i++)
            {
                Console.Write("\nIngrese 5 numeros {0}/5:", (i+1));
                numero = int.Parse(Console.ReadLine());
                acumulador += numero;

                if (flat)
                {
                    maximo = numero;
                    minimo = numero;

                    flat = false;
                }


                if (!flat && numero > maximo)
                {

                    maximo = numero;

                }

                if(!flat && numero < minimo)
                {

                    minimo = numero;

                }

            }

            promedio = (float) acumulador / i;
            Console.Write("\n\nEl promedio es: {0:#,###.00} \nEl numero Maximo es: {1}\nEl Numero Minimo es: {2}", promedio,maximo,minimo);

            Console.ReadLine();
            

        }
    }
}
