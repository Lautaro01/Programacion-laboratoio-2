﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio05
{
    class jercicio_05
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 05";

            int lista = 2;
            int numeroUsuario = 100;
            int primeraMitad;
            int segundaMitad;
            
           

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Los numeros medios entre el 1 y el {0} son: ",numeroUsuario);

            Console.ForegroundColor = ConsoleColor.White;
            for (int i = 1; i <= lista; i++)
            {
                primeraMitad = Gauss(i - 1);
                segundaMitad = Gauss(lista) - Gauss(i);

                if (primeraMitad == segundaMitad)
                {
                    Console.Write("{0} ", i);
                }

                if (lista == i)
                {
                    if (lista == numeroUsuario)
                    {
                        break;
                    }

                    lista++;
                    i = 1;
                }
            }
            Console.ReadLine();
        }

        public static int Gauss(int n)
        {
            int resultado = (n * n + 1 * n) / 2;
            return resultado;
        }
    }
}
