using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio02
{
  class Ejercicio_02
  {
    static void Main(string[] args)
    {
      Console.Title = "Ejercicio Nro 02";
      int numero;
      int cuadrado;
      int cubo;
      bool flat = true;

      while (flat)
      {

        Console.Write("Ingrese un numero: ");
        numero = int.Parse(Console.ReadLine());

        //if (numero > 0)
        //{
        //    cuadrado = (int)Math.Pow(numero, 2);
        //    cubo = (int)Math.Pow(numero, 3);

        //    Console.Write("\nSu numero elevado al cuadrado es: {0}\nSu numero elevado al cubo es: {1}", cuadrado, cubo);
        //    flat = false;
        //}
        //else
        //{

        //    Console.Write("ERROR. ¡Reingresar número!");
        //}

        while (numero < 0)
        {
          Console.BackgroundColor = ConsoleColor.Red;
          Console.Write("\nError, ingrese un numero mayor a 0!\n");
          Console.BackgroundColor = ConsoleColor.Black;
          Console.Write("\nIngrese un numero: ");
          numero = int.Parse(Console.ReadLine());
        }

        cuadrado = (int)Math.Pow(numero, 2);
        cubo = (int)Math.Pow(numero, 3);
        Console.Write("\nSu numero elevado al cuadrado es: {0}\nSu numero elevado al cubo es: {1}", cuadrado, cubo);

        Console.Read();
      }
    }
  }
}
