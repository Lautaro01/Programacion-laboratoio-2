﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            Entidades.Sello.mensaje = "Lautaro";



            Console.WriteLine(Entidades.Sello.imprimir());
           
            

            Entidades.Sello.color = ConsoleColor.White;
            
            Entidades.Sello.ImprimirEnColor();

            

            Console.Read();

            Entidades.Sello.borrar();


        }
    }
}
