﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class Ejercicio_04
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 04";

            int numero;
         
            int contador = 0;

            Console.Write("Ingrese un numero: ");
             
            numero = int.Parse(Console.ReadLine());

            Console.Write("Los numeros primos del 1 al {0} son: \n", numero);

            for (int i = 2; i < numero; i++)
            {
                for (int j = 1; j < numero; j++)
                {
                    if (numero % j == 0)
                    {
                        contador++;
                    }

                }

                if (contador <= 2)
                {
                    Console.Write("{0}-", numero);
                }

            }

            Console.Read();
        }
    }
}
