using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase03
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "Ejercicio Clase Nro 03";

      Cosa cosa = new Cosa();
      Cosa.Mostrar(cosa);

      Console.Write("Los atributos son: {0} ", Cosa.Mostrar(cosa));

      Console.ReadLine();
    }
  }
}
