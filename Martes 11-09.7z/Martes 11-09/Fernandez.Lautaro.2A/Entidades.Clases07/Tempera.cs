using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases07

{
  class Tempera
  {
    #region atributos

    private sbyte _cantidad;
    private ConsoleColor _color;
    private string _marca;

    #endregion


    #region Constructor
    public Tempera()
    {
      this._cantidad = 0;
      this._color = ConsoleColor.Black;
      this._marca = "";
    }



    public Tempera(sbyte cantidad, ConsoleColor color, string marca)
    {
      this._color = color;
      this._cantidad = cantidad;
      this._marca = marca;
    }
    #endregion

    #region Metodos

    private string Mostrar()
    {
      string retornar = " ";

      retornar += "Color: " + this._color + "\n";
      retornar +="Marca: " + this._marca + "\n";
      retornar +="Cantidad" + this._cantidad + "\n";

      return retornar;
    }

    #endregion

    #region Sobrecargas

    public static implicit operator string(Tempera temp)
    {
      return temp.Mostrar();
    }

    public static explicit operator sbyte(Tempera temp)
    {
      return temp._cantidad;
    }

    public static bool operator ==(Tempera temperaUno, Tempera temperaDos)
    {
      bool retorno = false;

      if (!(Object.Equals(temperaUno, null)) || !(Object.Equals(temperaDos, null)))
      {
        if (temperaUno._color == temperaDos._color && temperaUno._marca == temperaDos._marca)
        {
          retorno = true;
        }
      }
      return retorno;
    }


    public static bool operator !=(Tempera temperaUno, Tempera temperaDos)
    {
      return !(temperaUno == temperaDos);
    }

    public static Tempera operator +(Tempera tempera, sbyte cantidad)
    {
      Tempera temperaNueva = new Tempera((SByte)(cantidad + tempera._cantidad), tempera._color, tempera._marca);
      return temperaNueva;
    }


    public static Tempera operator +(Tempera temperaUno, Tempera temperaDos)
    {
      Tempera temperaNueva = new Tempera(temperaUno._cantidad, temperaUno._color, temperaUno._marca);

      if(temperaUno == temperaDos)
      {
        temperaNueva += temperaDos._cantidad;
      }

      return temperaNueva;
    }
    #endregion



  }
}
