using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase06w
{
  public partial class Form1 : Form
  {

    private EjercicioClase06.Pluma _pluma;
    private EjercicioClase06.Tinta _tinta;

    public Form1()
    {
      InitializeComponent();
    }

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      frmTinta form = new frmTinta();

      form.Show();

    }

    private void plumaToolStripMenuItem_Click(object sender, EventArgs e)
    {

    }

    private void administrarToolStripMenuItem_Click(object sender, EventArgs e)
    {

    }
  }
}
