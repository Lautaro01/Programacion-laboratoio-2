using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase06
{
  class Program
  {
    static void Main(string[] args)
    {
      
      //Pluma PlumaB = new Pluma();

      Tinta tintaParalaPluma = new Tinta();
      Pluma PlumaA = new Pluma(50,"Marca",tintaParalaPluma);
      Pluma PlumaB = new Pluma();
      Tinta tintaAComparar = new Tinta();

      if (PlumaB == tintaAComparar)
      {
        Console.Write("Las plumas son iguales");

        PlumaA += tintaAComparar;

        Console.Write(PlumaA);
      }
      else
      {
        Console.Write("Las plumas NO son iguales");
      }


        Console.ReadLine();

    }
  }
}
