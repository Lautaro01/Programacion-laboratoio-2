using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase06
{
  class Tinta
  {
    #region Atributos

    private ConsoleColor _color;
    private Etipotinta _tinta;

    #endregion

    #region Metodos

    public static string Mostrar(Tinta unaTinta)
    {
      return unaTinta.Mostrar();
    }

    private string Mostrar()
    {
      string retornar = " ";

      retornar += this._color;
      retornar += this._tinta;

      return retornar;
    }



    #endregion


    #region Constructores

    public Tinta()
    {
      this._color = ConsoleColor.Blue;
      this._tinta = Etipotinta.conBrillito;
    }

    public Tinta(ConsoleColor color) : this()
    {
      this._color = color;
    }

    public Tinta(Etipotinta tipo) : this()
    {
      this._tinta = tipo;
    }

    public Tinta(ConsoleColor color,Etipotinta tipo) 
    {
      this._tinta = tipo;
      this._color = color;
    }

    #endregion


    #region Sobrecarga De Operadores
    public static bool operator ==(Tinta tintaA, Tinta tintaB)
    {
      bool retornar = false;
      if(!(Object.Equals(tintaA,null))||!(Object.Equals(tintaB,null)))
      {
        if(tintaA._color == tintaB._color && tintaA._tinta == tintaB._tinta)
        {
         retornar = true;
        }
      }      
      return retornar;
    }

    public static bool operator !=(Tinta tintaA, Tinta tintaB)
    {
      return !(tintaA == tintaB);
    }
    #endregion
  }
}
